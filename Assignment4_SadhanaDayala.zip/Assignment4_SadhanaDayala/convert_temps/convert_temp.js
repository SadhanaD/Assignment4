"use strict";
var $ = function (id) { return document.getElementById(id); };


var clearTextBoxes = function () {
    $("degrees_entered").value = "";
    $("degrees_computed").value = "";
};

var toFahrenheit = function toFahrenheit() {
    clearTextBoxes();

    $("degree_label_1").firstChild.nodeValue = 'Enter C degrees:';
    $("degree_label_2").firstChild.nodeValue = 'Degrees Fahrenheit:';
}

var toCelsius = function toCelsius() {
    clearTextBoxes();

    $("degree_label_1").firstChild.nodeValue = 'Enter F degrees:';
    $("degree_label_2").firstChild.nodeValue = 'Degrees Celsius:';
}

var convertTemp = function () {
    var radioButtons = document.getElementsByTagName("input");
    var selectedId = '';

    for (var i = 0; i < radioButtons.length; i++) {
        if (radioButtons[i].type == "radio" && radioButtons[i].checked) {
            selectedId = radioButtons[i].id;
        }
    }

    var degree = $("degrees_entered").value;
    degree = parseInt(degree);

    if (isNaN(degree)) {
        alert("You must enter a valid number for degrees.");
    }
    else {
        if (selectedId == 'to_celsius') {
            degree = parseInt(degree);
            var cel = (degree - 32) * (5 / 9);

            $("degrees_computed").value = parseInt(cel);
        }

        if (selectedId == 'to_fahrenheit') {
            degree = parseInt(degree);
            var cel = (degree - 32) * (5 / 9);

            $("degrees_computed").value = parseInt(cel);
        }
    }
    return;
}


window.onload = function () {
    $("convert").onclick = convertTemp;
    $("to_celsius").onclick = toCelsius;
    $("to_fahrenheit").onclick = toFahrenheit;
    $("degrees_entered").focus();
};