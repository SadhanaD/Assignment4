var names = ["Ben", "Joel", "Judy", "Anne"];
var scores = [88, 98, 77, 88];

var $ = function (id) {
    return document.getElementById(id);
};

var displayResults = function () {
    var sum = 0;
    var max = 0;
    var maxId = 0;

    for (var i = 0; i < scores.length; i++) {
        if (scores[i] > max) {
            max = scores[i];
            maxId = i;
        }
        sum += scores[i];
    }
    var avg = sum / scores.length;

    $("results").innerHTML = "";

    $("results").innerHTML += "<br/><h2>Results</h2><br/>";
    $("results").innerHTML += "<p>Average Score = " + avg.toFixed(2) + "</p><br/>";
    $("results").innerHTML += "<p>High Scores = " + names[maxId] + " with a score of " + max + "</p>"
}

var addScore = function () {
    var name = $("name").value;
    var score = $("score").value;

    if ((name != "" && name != null) && (score >= 0 && score <= 100)) {
        names.push(name);
        scores.push(parseInt(score));

        displayScores();
        $("name").value = '';
        $("score").value = '';
    } else {
        alert("You must enter a name and a valid score");
    }
    $("name").focus();
}

var displayScores = function () {
    $("scores_table").innerHTML = "<h2>Scores</h2>";
    $("scores_table").innerHTML += "<tr><td><b>Name</b></td><td><b>Score</b></td></tr>"
    for (var i = 0; i < scores.length; i++) {
        $("scores_table").innerHTML += "<tr><td>" + names[i] + "</td><td>" + scores[i] +"</td></tr>"
    }
}

window.onload = function () {
    $("name").focus();
	$("add").onclick = addScore;
	$("display_results").onclick = displayResults;
	$("display_scores").onclick = displayScores;
};


